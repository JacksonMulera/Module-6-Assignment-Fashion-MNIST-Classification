# Install and load necessary libraries
install.packages("keras")
library(keras)
install_keras()  # This will install TensorFlow backend

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
c(c(x_train, y_train), c(x_test, y_test)) %<-% fashion_mnist

# Reshape and normalize the dataset
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))
x_train <- x_train / 255
x_test <- x_test / 255

# Convert class vectors to binary class matrices
y_train <- to_categorical(y_train, 10)
y_test <- to_categorical(y_test, 10)

# Define the CNN model using a class
FashionMNISTModel <- R6::R6Class(
  "FashionMNISTModel",
  
  public = list(
    model = NULL,
    
    initialize = function() {
      self$model <- self$build_model()
    },
    
    build_model = function() {
      model <- keras_model_sequential() %>%
        # Layer 1: Convolutional layer
        layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
        # Layer 2: Convolutional layer
        layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
        # Layer 3: Max pooling layer
        layer_max_pooling_2d(pool_size = c(2, 2)) %>%
        # Layer 4: Dropout layer
        layer_dropout(rate = 0.25) %>%
        # Layer 5: Flatten layer
        layer_flatten() %>%
        # Layer 6: Fully connected (dense) layer
        layer_dense(units = 128, activation = 'relu') %>%
        # Output layer
        layer_dense(units = 10, activation = 'softmax')
      
      model %>% compile(
        loss = 'categorical_crossentropy',
        optimizer = optimizer_adam(),
        metrics = c('accuracy')
      )
      model
    },
    
    train_model = function(x_train, y_train, epochs = 10, batch_size = 128) {
      self$model %>% fit(
        x_train, y_train,
        epochs = epochs, batch_size = batch_size,
        validation_split = 0.2
      )
    },
    
    evaluate_model = function(x_test, y_test) {
      results <- self$model %>% evaluate(x_test, y_test)
      cat('Test accuracy:', results$acc, '\n')
      cat('Test loss:', results$loss, '\n')
    },
    
    make_predictions = function(x_test, num_images = 2) {
      predictions <- self$model %>% predict(x_test[1:num_images,,,])
      predicted_classes <- apply(predictions, 1, which.max) - 1
      true_classes <- apply(y_test[1:num_images,], 1, which.max) - 1
      
      for (i in 1:num_images) {
        plot(as.raster(x_test[i,,,], max = 1))
        title(paste('True label:', true_classes[i], ', Predicted:', predicted_classes[i]))
      }
    }
  )
)

# Instantiate the model
fashion_mnist_model <- FashionMNISTModel$new()

# Train the model
fashion_mnist_model$train_model(x_train, y_train, epochs = 10, batch_size = 128)

# Evaluate the model
fashion_mnist_model$evaluate_model(x_test, y_test)

# Make predictions for a few images
fashion_mnist_model$make_predictions(x_test, num_images = 2)

